package alunos.infnet.assessmentjava;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import alunos.infnet.assessmentjava.API.DataService;

import alunos.infnet.assessmentjava.Model.tarefa;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Principal extends AppCompatActivity {

    private ListView mListView;
    private Retrofit retrofit;

    private List<tarefa> listaTarefa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        retrofit = new Retrofit.Builder()
                .baseUrl("http://infnet.educacao.ws/")
                .addConverterFactory(GsonConverterFactory.create()).build();

        mListView = findViewById(R.id.mListView);

        recuperarListaRetrofit();
    }

    private void recuperarListaRetrofit() {

        DataService service = retrofit.create(DataService.class);
        Call<List<tarefa>> call = service.recuperarTarefa();

        call.enqueue(new Callback<List<tarefa>>() {
            @Override
            public void onResponse(Call<List<tarefa>> call, Response<List<tarefa>> response) {

                if (response.isSuccessful()) {
                    listaTarefa = new ArrayList<>();
                    listaTarefa = response.body();

                    String[] descricao = new String[listaTarefa.size()];
                    for (int i = 1; i <= listaTarefa.size(); i++) {
                        descricao[i] = listaTarefa.get(i).getDescricao();

                        mListView.setAdapter(new ArrayAdapter<>(getApplicationContext(),
                                android.R.layout.simple_list_item_1, descricao));
                    }
                }
            }

            @Override
            public void onFailure(Call<List<tarefa>> call, Throwable t) {
                Toast.makeText(Principal.this, "Falhou!", Toast.LENGTH_SHORT).show();

            }
        });
    }

}
