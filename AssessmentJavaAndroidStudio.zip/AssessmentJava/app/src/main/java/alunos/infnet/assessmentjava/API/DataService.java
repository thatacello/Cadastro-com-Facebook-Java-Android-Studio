package alunos.infnet.assessmentjava.API;

import android.database.Observable;

import java.util.List;

import alunos.infnet.assessmentjava.Model.tarefa;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface DataService {

    @GET("dadosAtividades.php")
    Call<List<tarefa>>recuperarTarefa();

    @GET("dadosAtividades.php")
    Observable<tarefa> getTarefa(@Path("descricao") String descricao);

}
